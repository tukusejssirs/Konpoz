# Webhosting

@zorvar navrhuje zriesenie ‘riadneho’ webhostingu. @tukusejssirs nie je proti, no treba vybrat sprostredkovatela webhostingu a domeny. Mohlo by sa to hodit i do buducnosti na nejake testy/ulohy, ktore pravdepodobne este dostaneme. Ale kedze by sme mali plateny webhosting, nejake ‘zbieranie grosov’ by bolo nevyhnutne.

# Sprostredkovatel webhostingu

@zorvar navrhol na sprostredkovatela webhostingu (ponuka aj domeny) [Premium Hosting](https://www.premiumhosting.sk/hosting/). Na nase aktualne potreby postacuje balicek [Pro](https://www.premiumhosting.sk/hosting/pro/), ktory sa upravit aj na mieru. Vsetky nizsie uvedene ceny su **ceny za mesiac**

- priestor nam aktualne staci aj 100 MB, no ak to budeme chciet pouzit i v buducnosti, mozno bude lepsie porozmyslat o vacsom priestore (cena za 100 MB je 0,22 €)
- emailove schranky – aktualne nam postacuje aj jedna … @zorvar vsak naznacoval, ze by sa hodilo mat ich 6 (jednu pre kazdeho); 6 vsak stoji 0,40 €, no za tu cenu mozeme mat az 13 schranok (14 uz stoji 0,41 € xD)
- databazy – kvoli omuto nam nestaci balicek [Mini](https://www.premiumhosting.sk/hosting/mini/) (neobsahuje zaidne databazy) … aktualne nam staci jedna databaza (stoji 0,40 €), no zas, ak chceme mysliet aj na buduce pouzitie, mozno sa ziade viac …

Napriklad za 1000 MB priestoru, 13 emailovych schranok a 5 databaz by sme platili 1,98 € za mesiac. Samozrejme, treba ratat este s domenou.

# Domena
Najlacnejsia domena je `.eu`. Najlacnejsiu cenu za jej registraciu som nasiel na [name.com](https://www.name.com/domain/search-3-1/konpoz.eu) len za **4.99 $** ([google](https://www.google.sk/search?q=4.99+usd+in+eur&ie=utf-8&oe=utf-8&gws_rd=cr&ei=RkcaVsKPM4PvywP3sJjYDw) tvrdi, ze je to 4,39 €).

# Nazov stranky
Aky chceme nazov stranky? Ak to chceme pouzit aj na ine ucely ako na semproj3, mohlo by to byt aj cosi ine ako konpon.eu.

# Diskusia

@tukusejssirs by rad pocul od kazdeho z Vas nazor k tomuto vsetkemu. Vdaka. :)

@siduska @norton1119 @janchvojka @diduska
