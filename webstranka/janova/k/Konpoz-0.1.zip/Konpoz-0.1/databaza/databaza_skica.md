1. aktualny datum;
2. dedlajn datum prihlasenia (z formulara do databazy);
3. datum konani (z formulara do databazy);

- aktualny datum > dedlajn datum prihlasenia => prihlasovaci formular == kos;
- aktualny datum > datum konania => oznam o konani akcie == kos;
- zobraz zoznam konania akcii (z databazy do html);

|akcia menom |   datum konania | dedlajn prihlasenia |
|:----------:|:---------------:|:-------------------:|
| akcia 1    |    xx.xx.xxxx   |     xx.xx.xxxx      |
| akcia 2    |    xx.xx.xxxx   |     xx.xx.xxxx      |
| akcia 3    |    xx.xx.xxxx   |     xx.xx.xxxx      |
| akcia X    |    xx.xx.xxxx   |     xx.xx.xxxx      |
